<?php
/**
 * Checkout billing information form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-billing.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.9
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/** @global WC_Checkout $checkout */

?>

<?php if (wc_ship_to_billing_address_only() && WC()->cart->needs_shipping()) : ?>

    <div class="title">Billing address</div>

<?php else : ?>

    <div class="title">Billing address</div>

<?php endif; ?>

<?php do_action('woocommerce_before_checkout_billing_form', $checkout); ?>

<?php
$fields = $checkout->get_checkout_fields('billing');
$key_id = 0;
foreach ($fields as $key => $field) {

    if (isset($field['country_field'], $fields[$field['country_field']])) {
        $field['country'] = $checkout->get_value($field['country_field']);
    }
    if ($key_id == 0) echo '<div class="group">';
    if ($key == 'country_field') echo '<div class="select">';
    woocommerce_form_field_check($key, $field, $checkout->get_value($key));
    if ($key == 'country_field') echo '</div>';
    if ($key_id == 1) {
        echo '</div>';
        $key_id = 0;
    } else {
        $key_id++;
    }
}
if ($key_id == 1) {
    echo '</div>';
}
?>

<?php do_action('woocommerce_after_checkout_billing_form', $checkout); ?>

