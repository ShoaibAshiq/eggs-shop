<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

global $post, $product;
$columns = apply_filters('woocommerce_product_thumbnails_columns', 4);
$thumbnail_size = apply_filters('woocommerce_product_thumbnails_large_size', 'full');
$post_thumbnail_id = get_post_thumbnail_id($post->ID);
$full_size_image = wp_get_attachment_image_src($post_thumbnail_id, $thumbnail_size);
$placeholder = has_post_thumbnail() ? 'with-images' : 'without-images';
$wrapper_classes = apply_filters('woocommerce_single_product_image_gallery_classes', array(
    'woocommerce-product-gallery',
    'woocommerce-product-gallery--' . $placeholder,
    'woocommerce-product-gallery--columns-' . absint($columns),
    'images',
));
?>


<?php
if (has_post_thumbnail()) {
    global $post, $product;

    $attachment_ids = $product->get_gallery_image_ids();
    echo '<div class="slider slider--product">';
    if ($attachment_ids) {

        $html = '<div class="slide" style="background-image:url(' . get_the_post_thumbnail_url($post->ID, 'full') . ');"></div>';
        echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $attachment_id);
        foreach ($attachment_ids as $attachment_id) {
            $full_size_image = wp_get_attachment_image_src($attachment_id, 'full');
            $thumbnail = wp_get_attachment_image_src($attachment_id, 'shop_thumbnail');
            $attributes = array(
                'title' => get_post_field('post_title', $attachment_id),
                'data-caption' => get_post_field('post_excerpt', $attachment_id),
                'data-src' => $full_size_image[0],
                'data-large_image' => $full_size_image[0],
                'data-large_image_width' => $full_size_image[1],
                'data-large_image_height' => $full_size_image[2],
            );


            $html = '<div class="slide" style="background-image:url(' . $full_size_image[0] . ');"></div>';
            echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $attachment_id);
        }
    }
    echo '</div>';
    echo '<div class="slider-nav">';
    if ($attachment_ids) {
        $html = '<div class="slide" style="background-image:url(' . get_the_post_thumbnail_url($post->ID, 'full') . ');"></div>';
        echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $attachment_id);
        foreach ($attachment_ids as $attachment_id) {
            $full_size_image = wp_get_attachment_image_src($attachment_id, 'full');
            $thumbnail = wp_get_attachment_image_src($attachment_id, 'shop_thumbnail');
            $attributes = array(
                'title' => get_post_field('post_title', $attachment_id),
                'data-caption' => get_post_field('post_excerpt', $attachment_id),
                'data-src' => $full_size_image[0],
                'data-large_image' => $full_size_image[0],
                'data-large_image_width' => $full_size_image[1],
                'data-large_image_height' => $full_size_image[2],
            );

            $html = '<div class="slide" style="background-image:url(' . $full_size_image[0] . ');"></div>';
            echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $attachment_id);
        }
    }
    echo '</div>';
} else {
    $html = '<div class="woocommerce-product-gallery__image--placeholder">';
    $html .= sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src()), esc_html__('Awaiting product image', 'woocommerce'));
    $html .= '</div>';
    echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, get_post_thumbnail_id($post->ID));

}

?>